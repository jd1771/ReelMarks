const { getVideoInfo, getVideoLength } = require("./common/getYoutubeData.js");
const { getYoutubeTranscript } = require("./common/getYoutubeTranscript.js");
const { createBatches } = require("./common/createBatches.js");
const { getTimestamps } = require("./common/getTimestamps.js");
const Redis = require("ioredis");

const redisClient = new Redis({
    host: "reelmarks-ro.nopibf.ng.0001.usw1.cache.amazonaws.com",
    port: 6379,
});

redisClient.on("ready", () => {
    console.log("Connected to Redis server");
});

redisClient.on("error", (err) => {
    console.error("Error connecting to Redis server:", err);
    return {
        statusCode: 400,
        body: "Error connecting to Redis server",
    };
});

exports.handler = async function (event, context) {
    console.log(JSON.stringify(event));
    const pathParams = event.queryStringParameters || {};
    const { vidID } = pathParams;

    if (!vidID) {
        return {
            statusCode: 400,
            body: JSON.stringify("vidID is missing"),
        };
    }

    /*
    // Check if the vidID exists in Redis
    try {
        const result = await redisClient.get(vidID);
        if (result) {
            console.log("Retrieved from Redis");
            return {
                statusCode: 200,
                body: result,
            };
        }
    } catch (error) {
        return {
            statusCode: 400,
            body: "Error retrieving video",
        };
    }
    */

    console.log("starting video info request");
    const videoInfo = await getVideoInfo(vidID);

    console.log("videoInfo", videoInfo);

    if (videoInfo.error) {
        return {
            statusCode: 404,
            body: videoInfo,
        };
    }

    const lengthInSeconds = getVideoLength(videoInfo);

    // Return length in seconds
    if (lengthInSeconds) {
        return {
            statusCode: 200,
            body: lengthInSeconds,
        };
    }

    // Bail if the video length is longer than 3 hours
    if (lengthInSeconds > 10800) {
        return {
            statusCode: 400,
            body: { error: "Video exceeds max duration of 3 hours" },
        };
    }

    const transcriptResponse = await getYoutubeTranscript(vidID);

    if (transcriptResponse.error) {
        return {
            statusCode: 404,
            body: transcriptResponse,
        };
    }

    const prompt = `Summarize the following section from the video '${videoInfo.title}'. The summary should be a maximum of 20 words. Don't include spoilers for the video content. Summarize: `;
    const cleanedTranscript = transcriptResponse.map((t) => ({
        time: t.offset / 1000,
        text: t.text.replace(/[\r\n]/g, " ").replace(/[^a-zA-Z0-9 ]/g, ""),
    }));

    const batches = createBatches(cleanedTranscript);
    const timestamps = await getTimestamps(batches, prompt);

    // Create data object
    const data = {
        title: videoInfo.title,
        duration: lengthInSeconds,
        timestamps: timestamps,
    };

    // Save the transcription in Redis
    await redisClient.set(vidID, JSON.stringify(data));

    return {
        statusCode: 200,
        body: data,
    };
};
